package com.Allservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Logoutservlet")
public class Logoutservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		response.setContentType("Text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(false);// we are using old session that why using false

		if (session != null) {

			// time bound session expire method
			//session.setMaxInactiveInterval(10);
			// to distroy session
			session.invalidate();
			
			out.print("<h3>You have succesfully logout from application </h3>");
			RequestDispatcher Rd = request.getRequestDispatcher("index.html");
			Rd.include(request, response);

		} else {
			out.print("<h3>You have entered wrong details, please try again </h3>");
			RequestDispatcher Rd = request.getRequestDispatcher("index.html");
			Rd.include(request, response);
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

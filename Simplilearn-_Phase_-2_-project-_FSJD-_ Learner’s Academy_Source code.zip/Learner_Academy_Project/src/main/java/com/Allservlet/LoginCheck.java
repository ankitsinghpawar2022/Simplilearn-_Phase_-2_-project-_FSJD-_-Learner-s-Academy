package com.Allservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import javax.persistence.Query;
import org.hibernate.Session;

import com.Entities.Users;
import com.HibernateConnection.FactoryProvider;

@WebServlet("/LoginCheck")
public class LoginCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			response.setContentType("Text/html");
			PrintWriter out = response.getWriter();

			String Username = request.getParameter("uName");
			String Userpassword = request.getParameter("uPassword");
			String UserEmail = request.getParameter("uEmail");

			// write code to get data from user table to match password
			Session s = FactoryProvider.getFactory().openSession();
			Query q = s.createQuery("from Users");

			List<Users> list = q.getResultList();


			for (Users U : list) {
				// U.getUserPassword();

				if (Userpassword.equals(U.getUserPassword())&& (Username.equalsIgnoreCase(U.getUserName())))
				{
					// request to get session
					HttpSession session = request.getSession();
					session.setAttribute("UserEmail", UserEmail);
					response.sendRedirect("Deshboard.jsp");
				} else {
					out.print("<h3>You have entered wrong details, please try again </h3>");
					RequestDispatcher Rd = request.getRequestDispatcher("Login.jsp");
					Rd.include(request, response);
				}

			}

		} catch (

		Exception e) {
			System.out.println(e + "There is problem with site contact with IT Department");

		}
	}
}

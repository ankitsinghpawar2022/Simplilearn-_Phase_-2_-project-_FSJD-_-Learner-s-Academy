package com.Entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Users {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int UserID;

	private String UserName;

	private String UserPassword;

	private String UserEmail;

	private Date LoginDate;

	@Override
	public String toString() {
		return "Users [UserID=" + UserID + ", UserName=" + UserName + ", UserPassword=" + UserPassword + ", UserEmail="
				+ UserEmail + ", LoginDate=" + LoginDate + "]";
	}

	public int getUserID() {
		return UserID;
	}

	public void setUserID(int userID) {
		UserID = userID;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

	public String getUserPassword() {
		return UserPassword;
	}

	public void setUserPassword(String userPassword) {
		UserPassword = userPassword;
	}

	public String getUserEmail() {
		return UserEmail;
	}

	public void setUserEmail(String userEmail) {
		UserEmail = userEmail;
	}

	public Date getLoginDate() {
		return LoginDate;
	}

	public void setLoginDate(Date loginDate) {
		LoginDate = loginDate;
	}

	public Users(String userName, String userPassword, String userEmail, Date loginDate) {
		super();
		UserName = userName;
		UserPassword = userPassword;
		UserEmail = userEmail;
		LoginDate = loginDate;
	}

	public Users(int userID, String userName, String userPassword, String userEmail, Date loginDate) {
		super();
		UserID = userID;
		UserName = userName;
		UserPassword = userPassword;
		UserEmail = userEmail;
		LoginDate = loginDate;
	}

	public Users() {
		super();
		// TODO Auto-generated constructor stub
	}

}
